const bookData = require('./books');
const reviewData = require('./reviews');

module.exports = {
  books: bookData,
  reviews: reviewData
};